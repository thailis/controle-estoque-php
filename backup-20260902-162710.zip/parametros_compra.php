<?php
require_once 'conexao.php';

set_time_limit(300);

// Interpreta números em formato BR: "1.400" = 1400 (milhar), "1.234,56" = 1234.56.
function parseNumeroBrParametros(string $valor): ?float
{
    $valor = trim($valor);
    if ($valor === '') {
        return null;
    }
    if (str_contains($valor, ',')) {
        $valor = str_replace('.', '', $valor);
        $valor = str_replace(',', '.', $valor);
    } elseif (substr_count($valor, '.') >= 1) {
        $partes = explode('.', $valor);
        $pareceMilhar = true;
        for ($i = 1; $i < count($partes); $i++) {
            if (strlen($partes[$i]) !== 3 || !ctype_digit($partes[$i])) {
                $pareceMilhar = false;
                break;
            }
        }
        if ($pareceMilhar) {
            $valor = str_replace('.', '', $valor);
        }
    }
    return is_numeric($valor) ? (float) $valor : null;
}

function normalizarTextoParametros(string $texto): string
{
    $texto = mb_strtolower(trim($texto), 'UTF-8');
    $mapa = [
        'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a', 'ä' => 'a',
        'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
        'ó' => 'o', 'ò' => 'o', 'õ' => 'o', 'ô' => 'o', 'ö' => 'o',
        'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
        'ç' => 'c', ' ' => '_', '-' => '_',
    ];
    return strtr($texto, $mapa);
}

$mensagens = [];
$importados = 0;
$erros = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['arquivo_csv'])) {
    $arquivo = $_FILES['arquivo_csv']['tmp_name'];

    if ($_FILES['arquivo_csv']['error'] !== UPLOAD_ERR_OK) {
        $mensagens[] = "❌ Erro no upload do arquivo.";
    } else {
        $handle = fopen($arquivo, 'r');

        if ($handle === false) {
            $mensagens[] = "❌ Não foi possível abrir o arquivo.";
        } else {
            $primeiraLinha = fgets($handle);
            rewind($handle);
            $separador = (substr_count($primeiraLinha, ';') > substr_count($primeiraLinha, ',')) ? ';' : ',';

            $cabecalhoOriginal = fgetcsv($handle, 0, $separador, '"', '\\');
            if ($cabecalhoOriginal === false) {
                $mensagens[] = "❌ Arquivo vazio ou inválido.";
            } else {
                if (isset($cabecalhoOriginal[0])) {
                    $cabecalhoOriginal[0] = preg_replace('/^\xEF\xBB\xBF/', '', $cabecalhoOriginal[0]);
                }
                $cabecalho = array_map('normalizarTextoParametros', $cabecalhoOriginal);

                $mapaColunas = [
                    'codigo_componente' => [
                    'codigo_componente',
                    'componente',
                    'codigo do componente',
                    'codigo componente',
                    'cod componente',
                    'codigo_do_componente'
                ],
                    'moq' => ['moq'],
                    'frozen_zone_dias' => ['frozen_zone_dias', 'frozen_zone', 'frozenzone'],
                    'transit_time_dias' => ['transit_time_dias', 'transit_time', 'transittime'],
                    'estoque_min_dias' => ['estoque_min_dias', 'min', 'min_dias'],
                    'estoque_max_dias' => ['estoque_max_dias', 'max', 'max_dias'],
                ];
                $indices = [];
                foreach ($mapaColunas as $campo => $candidatos) {
                    $indices[$campo] = null;
                    foreach ($candidatos as $c) {
                        $pos = array_search($c, $cabecalho, true);
                        if ($pos !== false) { $indices[$campo] = $pos; break; }
                    }
                }

                if ($indices['codigo_componente'] === null) {
                    $mensagens[] = "❌ Não encontrei a coluna do componente. Use 'codigo_componente' no cabeçalho.";
                } else {
                    if (isset($_POST['limpar_tabela'])) {
                        mysqli_query($conn, "TRUNCATE TABLE parametros_compra");
                        $mensagens[] = "🗑️ Tabela 'parametros_compra' esvaziada antes da importação.";
                    }

                    $tamanhoLote = 200;
                    $lote = [];

                    $flushLote = function () use ($conn, &$lote, &$importados, &$erros, &$mensagens) {
                        if (empty($lote)) return;
                        $linhasSql = [];
                        foreach ($lote as $v) {
                            $vals = array_map(function ($x) use ($conn) {
                                return $x === null ? 'NULL' : (is_numeric($x) ? $x : "'" . mysqli_real_escape_string($conn, (string) $x) . "'");
                            }, $v);
                            $linhasSql[] = '(' . implode(', ', $vals) . ')';
                        }
                        $sql = "INSERT INTO parametros_compra (codigo_componente, moq, frozen_zone_dias, transit_time_dias, estoque_min_dias, estoque_max_dias) VALUES "
                            . implode(', ', $linhasSql)
                            . " ON DUPLICATE KEY UPDATE moq = VALUES(moq), frozen_zone_dias = VALUES(frozen_zone_dias), "
                            . "transit_time_dias = VALUES(transit_time_dias), estoque_min_dias = VALUES(estoque_min_dias), estoque_max_dias = VALUES(estoque_max_dias)";
                        if (mysqli_query($conn, $sql)) {
                            $importados += count($lote);
                        } else {
                            $erros += count($lote);
                            $mensagens[] = "⚠️ Erro ao inserir um lote de " . count($lote) . " linha(s): " . mysqli_error($conn);
                        }
                        $lote = [];
                    };

                    mysqli_autocommit($conn, false);

                    $linhaNum = 1;
                    while (($linha = fgetcsv($handle, 0, $separador, '"', '\\')) !== false) {
                        $linhaNum++;

                        if (count(array_filter($linha, fn($v) => trim((string) $v) !== '')) === 0) {
                            continue;
                        }
                        if (count($linha) !== count($cabecalho)) {
                            $erros++;
                            $mensagens[] = "⚠️ Linha $linhaNum ignorada (número de colunas não confere).";
                            continue;
                        }

                        $codigo = trim((string) ($linha[$indices['codigo_componente']] ?? ''));
                        if ($codigo === '') {
                            $erros++;
                            $mensagens[] = "⚠️ Linha $linhaNum ignorada: componente vazio.";
                            continue;
                        }

                        $moq = $indices['moq'] !== null ? parseNumeroBrParametros((string) ($linha[$indices['moq']] ?? '')) : null;
                        $frozen = $indices['frozen_zone_dias'] !== null ? parseNumeroBrParametros((string) ($linha[$indices['frozen_zone_dias']] ?? '')) : null;
                        $transit = $indices['transit_time_dias'] !== null ? parseNumeroBrParametros((string) ($linha[$indices['transit_time_dias']] ?? '')) : null;
                        $min = $indices['estoque_min_dias'] !== null ? parseNumeroBrParametros((string) ($linha[$indices['estoque_min_dias']] ?? '')) : null;
                        $max = $indices['estoque_max_dias'] !== null ? parseNumeroBrParametros((string) ($linha[$indices['estoque_max_dias']] ?? '')) : null;

                        $lote[] = [
                            $codigo,
                            $moq,
                            $frozen !== null ? (int) $frozen : null,
                            $transit !== null ? (int) $transit : null,
                            $min !== null ? (int) $min : null,
                            $max !== null ? (int) $max : null,
                        ];

                        if (count($lote) >= $tamanhoLote) {
                            $flushLote();
                        }
                    }
                    $flushLote();

                    mysqli_commit($conn);
                    mysqli_autocommit($conn, true);

                    $mensagens[] = "✅ Importação concluída: $importados linha(s) importada(s), $erros erro(s).";
                }
            }
            fclose($handle);
        }
    }
}

// Inclusão/edição manual direto pelo site, sem CSV. Como codigo_componente já é
// chave única na tabela (mesma UNIQUE KEY usada pelo upsert do import), a inclusão
// usa o mesmo INSERT ... ON DUPLICATE KEY UPDATE do CSV — cadastrar um componente
// que já existe simplesmente atualiza os parâmetros dele, sem duplicar linha.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'inserir_manual') {
    $codigoManual = trim($_POST['componente_manual'] ?? '');
    $moqManual = parseNumeroBrParametros(trim($_POST['moq_manual'] ?? ''));
    $frozenManual = parseNumeroBrParametros(trim($_POST['frozen_manual'] ?? ''));
    $transitManual = parseNumeroBrParametros(trim($_POST['transit_manual'] ?? ''));
    $minManual = parseNumeroBrParametros(trim($_POST['min_manual'] ?? ''));
    $maxManual = parseNumeroBrParametros(trim($_POST['max_manual'] ?? ''));

    $flash = 'erro_dados';
    if ($codigoManual !== '') {
        $frozenIntManual = $frozenManual !== null ? (int) $frozenManual : null;
        $transitIntManual = $transitManual !== null ? (int) $transitManual : null;
        $minIntManual = $minManual !== null ? (int) $minManual : null;
        $maxIntManual = $maxManual !== null ? (int) $maxManual : null;

        $stmtManual = mysqli_prepare($conn, "
            INSERT INTO parametros_compra (codigo_componente, moq, frozen_zone_dias, transit_time_dias, estoque_min_dias, estoque_max_dias)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE moq = VALUES(moq), frozen_zone_dias = VALUES(frozen_zone_dias),
                transit_time_dias = VALUES(transit_time_dias), estoque_min_dias = VALUES(estoque_min_dias),
                estoque_max_dias = VALUES(estoque_max_dias)
        ");
        mysqli_stmt_bind_param(
            $stmtManual, "sdiiii",
            $codigoManual, $moqManual, $frozenIntManual, $transitIntManual, $minIntManual, $maxIntManual
        );
        mysqli_stmt_execute($stmtManual);
        mysqli_stmt_close($stmtManual);
        $flash = 'inserido';
    }

    header('Location: parametros_compra.php?' . http_build_query([
        'pagina'     => $_POST['pagina_atual'] ?? 1,
        'busca'      => $_POST['busca_atual'] ?? '',
        'fornecedor' => $_POST['fornecedor_atual'] ?? '',
        'flash'      => $flash,
    ]));
    exit;
}

// Edição direta dos parâmetros de um componente já cadastrado, sem CSV.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'editar_registro') {
    $codigoEditar = trim($_POST['codigo_editar'] ?? '');
    $moqEditado = parseNumeroBrParametros(trim($_POST['moq_editado'] ?? ''));
    $frozenEditado = parseNumeroBrParametros(trim($_POST['frozen_editado'] ?? ''));
    $transitEditado = parseNumeroBrParametros(trim($_POST['transit_editado'] ?? ''));
    $minEditado = parseNumeroBrParametros(trim($_POST['min_editado'] ?? ''));
    $maxEditado = parseNumeroBrParametros(trim($_POST['max_editado'] ?? ''));

    $flash = 'erro_dados';
    if ($codigoEditar !== '') {
        $frozenIntEditado = $frozenEditado !== null ? (int) $frozenEditado : null;
        $transitIntEditado = $transitEditado !== null ? (int) $transitEditado : null;
        $minIntEditado = $minEditado !== null ? (int) $minEditado : null;
        $maxIntEditado = $maxEditado !== null ? (int) $maxEditado : null;

        $stmtEditar = mysqli_prepare($conn, "
            UPDATE parametros_compra
            SET moq = ?, frozen_zone_dias = ?, transit_time_dias = ?, estoque_min_dias = ?, estoque_max_dias = ?
            WHERE codigo_componente = ?
        ");
        mysqli_stmt_bind_param(
            $stmtEditar, "diiiis",
            $moqEditado, $frozenIntEditado, $transitIntEditado, $minIntEditado, $maxIntEditado, $codigoEditar
        );
        mysqli_stmt_execute($stmtEditar);
        mysqli_stmt_close($stmtEditar);
        $flash = 'editado';
    }

    header('Location: parametros_compra.php?' . http_build_query([
        'pagina'     => $_POST['pagina_atual'] ?? 1,
        'busca'      => $_POST['busca_atual'] ?? '',
        'fornecedor' => $_POST['fornecedor_atual'] ?? '',
        'flash'      => $flash,
    ]));
    exit;
}

function h(mixed $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

$porPagina = 50;
$pagina = isset($_GET['pagina']) ? max(1, (int)$_GET['pagina']) : 1;
$offset = ($pagina - 1) * $porPagina;

$busca = isset($_GET['busca']) ? trim($_GET['busca']) : '';
$fornecedorFiltro = isset($_GET['fornecedor']) ? trim($_GET['fornecedor']) : '';
$editando = isset($_GET['editar']) ? trim($_GET['editar']) : '';
$flash = isset($_GET['flash']) ? trim($_GET['flash']) : '';

$flashMap = [
    'inserido'   => ['success', '✅ Componente cadastrado/atualizado com sucesso.'],
    'editado'    => ['success', '✅ Parâmetros atualizados.'],
    'erro_dados' => ['danger', '❌ Informe ao menos o código do componente.'],
];

$condicoes = [];
$params = [];
$tipos = '';

if ($busca !== '') {
    $condicoes[] = "p.codigo_componente LIKE ?";
    $buscaLike = "%$busca%";
    $params[] = $buscaLike;
    $tipos .= 's';
}

if ($fornecedorFiltro !== '') {
    $condicoes[] = "EXISTS (SELECT 1 FROM bomnova b2 WHERE TRIM(b2.codigo_componente) = TRIM(p.codigo_componente) AND TRIM(b2.fornecedor) = ?)";
    $params[] = $fornecedorFiltro;
    $tipos .= 's';
}

$where = $condicoes ? ('WHERE ' . implode(' AND ', $condicoes)) : '';

// Listas pros campos de sugestão/filtro
$componentesDisponiveis = [];
$resComp = mysqli_query($conn, "SELECT DISTINCT TRIM(codigo_componente) AS codigo FROM bomnova WHERE codigo_componente IS NOT NULL AND TRIM(codigo_componente) <> '' ORDER BY codigo");
if ($resComp) {
    while ($linhaComp = mysqli_fetch_assoc($resComp)) {
        $componentesDisponiveis[] = $linhaComp['codigo'];
    }
}

$fornecedoresDisponiveis = [];
$resForn = mysqli_query($conn, "SELECT DISTINCT TRIM(fornecedor) AS fornecedor FROM bomnova WHERE fornecedor IS NOT NULL AND TRIM(fornecedor) <> '' ORDER BY fornecedor");
if ($resForn) {
    while ($linhaForn = mysqli_fetch_assoc($resForn)) {
        $fornecedoresDisponiveis[] = $linhaForn['fornecedor'];
    }
}

$sqlTotal = "SELECT COUNT(*) AS total FROM parametros_compra p $where";
if (!empty($params)) {
    $stmtTotal = mysqli_prepare($conn, $sqlTotal);
    mysqli_stmt_bind_param($stmtTotal, $tipos, ...$params);
    mysqli_stmt_execute($stmtTotal);
    $resultTotal = mysqli_stmt_get_result($stmtTotal);
} else {
    $resultTotal = mysqli_query($conn, $sqlTotal);
}
$total = mysqli_fetch_assoc($resultTotal)['total'];
$totalPaginas = max(1, ceil($total / $porPagina));

// Quantos têm os 5 parâmetros completos (é o que conta pro planejamento de compras)
$sqlCompletos = "SELECT COUNT(*) AS total FROM parametros_compra p $where "
    . ($where === '' ? 'WHERE ' : ' AND ')
    . "p.moq IS NOT NULL AND p.frozen_zone_dias IS NOT NULL AND p.transit_time_dias IS NOT NULL AND p.estoque_min_dias IS NOT NULL AND p.estoque_max_dias IS NOT NULL";
if (!empty($params)) {
    $stmtCompletos = mysqli_prepare($conn, $sqlCompletos);
    mysqli_stmt_bind_param($stmtCompletos, $tipos, ...$params);
    mysqli_stmt_execute($stmtCompletos);
    $resultCompletos = mysqli_stmt_get_result($stmtCompletos);
} else {
    $resultCompletos = mysqli_query($conn, $sqlCompletos);
}
$totalCompletos = (int) (mysqli_fetch_assoc($resultCompletos)['total'] ?? 0);

// Exportação CSV: traz TODOS os registros filtrados
if (($_GET['exportar'] ?? '') === 'csv') {
    $sqlExport = "SELECT p.codigo_componente, p.moq, p.frozen_zone_dias, p.transit_time_dias, p.estoque_min_dias, p.estoque_max_dias FROM parametros_compra p $where ORDER BY p.codigo_componente";
    if (!empty($params)) {
        $stmtExport = mysqli_prepare($conn, $sqlExport);
        mysqli_stmt_bind_param($stmtExport, $tipos, ...$params);
        mysqli_stmt_execute($stmtExport);
        $resultExport = mysqli_stmt_get_result($stmtExport);
    } else {
        $resultExport = mysqli_query($conn, $sqlExport);
    }
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="parametros-compra-' . date('Y-m-d-His') . '.csv"');
    echo "\xEF\xBB\xBF";
    $saida = fopen('php://output', 'w');
    fputcsv($saida, ['codigo_componente', 'moq', 'frozen_zone_dias', 'transit_time_dias', 'estoque_min_dias', 'estoque_max_dias'], ';', '"', '');
    while ($linha = mysqli_fetch_assoc($resultExport)) {
        fputcsv($saida, [
            $linha['codigo_componente'], $linha['moq'], $linha['frozen_zone_dias'],
            $linha['transit_time_dias'], $linha['estoque_min_dias'], $linha['estoque_max_dias'],
        ], ';', '"', '');
    }
    fclose($saida);
    exit;
}

$sql = "SELECT p.codigo_componente, p.moq, p.frozen_zone_dias, p.transit_time_dias, p.estoque_min_dias, p.estoque_max_dias,
               bg.fornecedores
        FROM parametros_compra p
        LEFT JOIN (
            SELECT TRIM(codigo_componente) AS codigo_componente,
                   GROUP_CONCAT(DISTINCT NULLIF(TRIM(fornecedor), '') ORDER BY TRIM(fornecedor) SEPARATOR ', ') AS fornecedores
            FROM bomnova
            GROUP BY TRIM(codigo_componente)
        ) bg ON bg.codigo_componente = TRIM(p.codigo_componente)
        $where
        ORDER BY p.codigo_componente
        LIMIT ? OFFSET ?";

$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $tipos . 'ii', ...array_merge($params, [$porPagina, $offset]));
} else {
    mysqli_stmt_bind_param($stmt, 'ii', $porPagina, $offset);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$rows = [];
while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>⚙️ Parâmetros de Compra</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; padding: 20px; }
        .card { border-radius: 15px; box-shadow: 0 2px 20px rgba(0,0,0,0.08); }
        .bg-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; }
        .table th { background: #f8f9fa; white-space: nowrap; }
        .table td { white-space: nowrap; }
        .badge-completo { background: #eaf8f0; color: #247a4d; }
        .badge-incompleto { background: #fff7df; color: #a96600; }
        summary { cursor: pointer; font-weight: 700; color: #405164; }
        .text-truncate-cell {
            display: inline-block;
            max-width: 220px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 1180px;">
        <nav class="d-flex flex-wrap gap-2 mb-3" aria-label="Navegação do sistema">
            <a class="btn btn-outline-secondary btn-sm" href="index.php">🏠 Dashboard</a>
            <a class="btn btn-outline-secondary btn-sm" href="estoque.php">Estoque</a>
            <a class="btn btn-outline-secondary btn-sm" href="edi.php">EDI</a>
            <a class="btn btn-outline-secondary btn-sm" href="bomnova.php">BOM</a>
            <a class="btn btn-outline-secondary btn-sm" href="programacao.php">Programação</a>
            <a class="btn btn-outline-secondary btn-sm" href="parametros_compra.php">Parâmetros</a>
            <a class="btn btn-outline-secondary btn-sm" href="evolucao_geral.php">Evolução geral</a>
            <a class="btn btn-outline-secondary btn-sm" href="planejamento_compras.php">Planejamento de compras</a>
        </nav>
        <div class="card bg-primary text-white p-4 mb-4">
            <h1>⚙️ Parâmetros de Compra</h1>
            <p class="mb-0">
                <?php echo number_format($total, 0, ',', '.'); ?> componente(s) na base
                • <?php echo number_format($totalCompletos, 0, ',', '.'); ?> com os 5 parâmetros completos (entram no planejamento)
            </p>
        </div>

        <?php if ($flash !== '' && isset($flashMap[$flash])): ?>
            <div class="alert alert-<?php echo $flashMap[$flash][0]; ?> py-2"><?php echo $flashMap[$flash][1]; ?></div>
        <?php endif; ?>

        <datalist id="lista_componentes">
            <?php foreach ($componentesDisponiveis as $c): ?>
                <option value="<?php echo h($c); ?>">
            <?php endforeach; ?>
        </datalist>

        <div class="card p-3 mb-4">
            <details <?php echo !empty($mensagens) ? 'open' : ''; ?>>
                <summary>📥 Importar novo arquivo CSV</summary>
                <div class="mt-3">
                    <?php if (!empty($mensagens)): ?>
                    <div class="mb-3">
                        <?php foreach ($mensagens as $msg): ?>
                            <div><?php echo htmlspecialchars($msg); ?></div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data" class="row g-2 align-items-end">
                        <div class="col-12 col-md-6">
                            <label class="form-label">Arquivo CSV</label>
                            <input type="file" name="arquivo_csv" accept=".csv" class="form-control" required>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="limpar_tabela" id="limpar_tabela">
                                <label class="form-check-label" for="limpar_tabela">
                                    Limpar tabela antes de importar
                                </label>
                            </div>
                        </div>
                        <div class="col-12 col-md-2">
                            <button type="submit" class="btn btn-primary w-100">Importar</button>
                        </div>
                    </form>

                    <hr>
                    <small class="text-muted">
                        <strong>Colunas esperadas no CSV</strong> (primeira linha = cabeçalho, qualquer ordem):<br>
                        <code>codigo_componente, moq, frozen_zone_dias, transit_time_dias, estoque_min_dias, estoque_max_dias</code><br>
                        Todas as colunas exceto <code>codigo_componente</code> são opcionais — mas a data sugerida de compra só é calculada para componentes com <strong>todos</strong> os 5 valores preenchidos.<br>
                        <code>estoque_min_dias</code>/<code>estoque_max_dias</code> = dias de cobertura de estoque desejados (não quantidade). <code>frozen_zone_dias</code> + <code>transit_time_dias</code> = tempo mínimo de reação (dias) entre decidir comprar e o material chegar.<br>
                        Separador: vírgula ou ponto e vírgula (detectado automaticamente).
                    </small>
                </div>
            </details>
        </div>

        <div class="card p-3 mb-4">
            <details>
                <summary>➕ Novo componente (cadastro manual)</summary>
                <form method="POST" class="row g-2 align-items-end mt-3">
                    <input type="hidden" name="acao" value="inserir_manual">
                    <input type="hidden" name="pagina_atual" value="<?php echo $pagina; ?>">
                    <input type="hidden" name="busca_atual" value="<?php echo h($busca); ?>">
                    <input type="hidden" name="fornecedor_atual" value="<?php echo h($fornecedorFiltro); ?>">
                    <div class="col-auto">
                        <label class="form-label small mb-1">Componente *</label>
                        <input type="text" name="componente_manual" list="lista_componentes" class="form-control form-control-sm" style="width:150px" required>
                    </div>
                    <div class="col-auto">
                        <label class="form-label small mb-1">MOQ</label>
                        <input type="text" name="moq_manual" class="form-control form-control-sm text-end" style="width:100px">
                    </div>
                    <div class="col-auto">
                        <label class="form-label small mb-1">Frozen Zone (dias)</label>
                        <input type="text" name="frozen_manual" class="form-control form-control-sm text-end" style="width:110px">
                    </div>
                    <div class="col-auto">
                        <label class="form-label small mb-1">Transit Time (dias)</label>
                        <input type="text" name="transit_manual" class="form-control form-control-sm text-end" style="width:110px">
                    </div>
                    <div class="col-auto">
                        <label class="form-label small mb-1">Estoque Min (dias)</label>
                        <input type="text" name="min_manual" class="form-control form-control-sm text-end" style="width:110px">
                    </div>
                    <div class="col-auto">
                        <label class="form-label small mb-1">Estoque Max (dias)</label>
                        <input type="text" name="max_manual" class="form-control form-control-sm text-end" style="width:110px">
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary btn-sm">Salvar</button>
                    </div>
                    <div class="col-12">
                        <small class="text-muted">Se o componente já existir na tabela, os parâmetros dele são atualizados (mesmo comportamento do CSV).</small>
                    </div>
                </form>
            </details>
        </div>

        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-auto flex-grow-1">
                    <input type="text" name="busca" class="form-control" placeholder="Buscar por componente..." value="<?php echo h($busca); ?>">
                </div>
                <div class="col-auto">
                    <select name="fornecedor" class="form-select" onchange="this.form.submit()">
                        <option value="">Todos os fornecedores</option>
                        <?php foreach ($fornecedoresDisponiveis as $f): ?>
                            <option value="<?php echo h($f); ?>" <?php echo $fornecedorFiltro === $f ? 'selected' : ''; ?>><?php echo h($f); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                    <a href="parametros_compra.php" class="btn btn-outline-secondary">Limpar</a>
                    <a href="?busca=<?php echo urlencode($busca); ?>&fornecedor=<?php echo urlencode($fornecedorFiltro); ?>&exportar=csv" class="btn btn-outline-primary">Exportar CSV</a>
                </div>
            </form>
        </div>

        <div class="card">
            <div class="card-body table-responsive">
                <table class="table table-hover table-sm">
                    <thead>
                        <tr>
                            <th>Componente</th>
                            <th>Fornecedor</th>
                            <th class="text-end">MOQ</th>
                            <th class="text-end">Frozen Zone (dias)</th>
                            <th class="text-end">Transit Time (dias)</th>
                            <th class="text-end">Estoque Min (dias)</th>
                            <th class="text-end">Estoque Max (dias)</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($rows)): ?>
                            <tr><td colspan="8" class="text-center text-muted">Nenhum registro encontrado.</td></tr>
                        <?php else: ?>
                            <?php foreach ($rows as $row): ?>
                                <?php
                                    $codigoLinha = $row['codigo_componente'] ?? '';
                                    $emEdicao = ($editando !== '' && $editando === $codigoLinha);
                                    $linkVoltar = '?pagina=' . $pagina . '&busca=' . urlencode($busca) . '&fornecedor=' . urlencode($fornecedorFiltro);
                                ?>
                                <tr>
                                    <td><strong><?php echo h($codigoLinha); ?></strong></td>
                                    <td title="<?php echo h($row['fornecedores'] ?? ''); ?>"><span class="text-truncate-cell"><?php echo h($row['fornecedores'] ?? '—'); ?></span></td>

                                    <?php if ($emEdicao): ?>
                                        <td colspan="6">
                                            <form method="POST" class="d-flex gap-2 align-items-center flex-wrap m-0">
                                                <input type="hidden" name="acao" value="editar_registro">
                                                <input type="hidden" name="codigo_editar" value="<?php echo h($codigoLinha); ?>">
                                                <input type="hidden" name="pagina_atual" value="<?php echo $pagina; ?>">
                                                <input type="hidden" name="busca_atual" value="<?php echo h($busca); ?>">
                                                <input type="hidden" name="fornecedor_atual" value="<?php echo h($fornecedorFiltro); ?>">
                                                <input type="text" name="moq_editado" class="form-control form-control-sm text-end" style="width:90px" value="<?php echo h($row['moq'] ?? ''); ?>" placeholder="MOQ">
                                                <input type="text" name="frozen_editado" class="form-control form-control-sm text-end" style="width:90px" value="<?php echo h($row['frozen_zone_dias'] ?? ''); ?>" placeholder="Frozen">
                                                <input type="text" name="transit_editado" class="form-control form-control-sm text-end" style="width:90px" value="<?php echo h($row['transit_time_dias'] ?? ''); ?>" placeholder="Transit">
                                                <input type="text" name="min_editado" class="form-control form-control-sm text-end" style="width:90px" value="<?php echo h($row['estoque_min_dias'] ?? ''); ?>" placeholder="Min">
                                                <input type="text" name="max_editado" class="form-control form-control-sm text-end" style="width:90px" value="<?php echo h($row['estoque_max_dias'] ?? ''); ?>" placeholder="Max">
                                                <button type="submit" class="btn btn-success btn-sm">Salvar</button>
                                                <a href="<?php echo $linkVoltar; ?>" class="btn btn-outline-secondary btn-sm">Cancelar</a>
                                            </form>
                                        </td>
                                    <?php else: ?>
                                        <td class="text-end"><?php echo $row['moq'] !== null ? number_format((float) $row['moq'], 0, ',', '.') : '—'; ?></td>
                                        <td class="text-end"><?php echo $row['frozen_zone_dias'] ?? '—'; ?></td>
                                        <td class="text-end"><?php echo $row['transit_time_dias'] ?? '—'; ?></td>
                                        <td class="text-end"><?php echo $row['estoque_min_dias'] ?? '—'; ?></td>
                                        <td class="text-end"><?php echo $row['estoque_max_dias'] ?? '—'; ?></td>
                                        <td>
                                            <a href="<?php echo $linkVoltar; ?>&editar=<?php echo urlencode($codigoLinha); ?>" class="btn btn-outline-secondary btn-sm">Editar</a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-3">
            <div>
                <?php if ($pagina > 1): ?>
                    <a href="?pagina=<?php echo $pagina - 1; ?>&busca=<?php echo urlencode($busca); ?>&fornecedor=<?php echo urlencode($fornecedorFiltro); ?>" class="btn btn-outline-primary btn-sm">← Anterior</a>
                <?php endif; ?>
            </div>
            <div class="text-muted">Página <?php echo $pagina; ?> de <?php echo $totalPaginas; ?></div>
            <div>
                <?php if ($pagina < $totalPaginas): ?>
                    <a href="?pagina=<?php echo $pagina + 1; ?>&busca=<?php echo urlencode($busca); ?>&fornecedor=<?php echo urlencode($fornecedorFiltro); ?>" class="btn btn-outline-primary btn-sm">Próxima →</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-outline-secondary">Voltar ao Dashboard</a>
        </div>
    </div>
</body>
</html>
